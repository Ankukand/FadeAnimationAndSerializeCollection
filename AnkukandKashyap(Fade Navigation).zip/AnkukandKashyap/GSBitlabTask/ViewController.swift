//
//  ViewController.swift
//  GSBitlabTask
//
//  Created by Anku on 17/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit
let reuseIdentifier = "CellIdentifer";
class ViewController: UIViewController , UICollectionViewDelegate, UICollectionViewDataSource{
    var sizeArray = NSMutableArray()
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Displaying collectionView cells as (x,y,x,x,y,x,x,x,y,x,x,x,x,y......)
        for index in 1...1000 {
            for _ in 1...index {
                print("30")
                sizeArray.add(CGSize(width: 30, height: 30))
            }
            print(",40")
            sizeArray.add(CGSize(width: 40, height: 40))
        }
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        configInitial()
    }
    private func configInitial() {
        // CollectionView's Settings
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.contentInsetAdjustmentBehavior = .never
        // NavigationController's Settings
        title = "Navigation Bar"
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor (red: 1.0/255.0, green: 1.0/255.0, blue: 1.0/255.0, alpha: 0)]
        navigationController?.navigationBar.tintColor = UIColor (red: 1.0/255.0, green: 1.0/255.0, blue: 1.0/255.0, alpha: 0)
        self.collectionView.backgroundColor = .cyan
        self.navigationController?.navigationBar.backgroundColor = .cyan
        self.view.backgroundColor = .cyan
    }
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 1000
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as UICollectionViewCell
        cell.backgroundColor = randomColor()
        
        return cell
    }
    //MARK: - Layout Function
    @objc(collectionView:layout:sizeForItemAtIndexPath:)
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return sizeArray[indexPath.row] as! CGSize
    }
    //Random Colours for collectionView cells
    func randomColor() -> UIColor{
        let red = CGFloat(drand48())
        let green = CGFloat(drand48())
        let blue = CGFloat(drand48())
        return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
    //Hidding Status Bar
    override var prefersStatusBarHidden: Bool {
        return true
    }
}
// ScrollView when scrolling then colour of navigation bar will change from cyan to Pink
extension ViewController {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        var offset = scrollView.contentOffset.y / 150
        if offset > 1 {
            offset = 1
        }
        
        let whiteColor = UIColor(red: 260.0/255.0, green: 65.0/255.0, blue: 198.0/255.0, alpha: offset)
        let blackColor = UIColor (red: 11.0/255.0, green: 34.0/255.0, blue: 199.0/255.0, alpha: offset)
        navigationController?.navigationBar.tintColor = blackColor
        navigationController?.navigationBar.backgroundColor = whiteColor
        navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: blackColor]
    }
}

